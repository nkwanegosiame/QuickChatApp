/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.quickchatapp;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Grade12teacher
 */
public class QuickChatAppTest {
    
    public QuickChatAppTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class QuickChatApp.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        QuickChatApp.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class QuickChatApp.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        QuickChatApp.registerUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class QuickChatApp.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        boolean expResult = false;
        boolean result = QuickChatApp.loginUser();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of runMessageSystem method, of class QuickChatApp.
     */
    @Test
    public void testRunMessageSystem() {
        System.out.println("runMessageSystem");
        QuickChatApp.runMessageSystem();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sendMessages method, of class QuickChatApp.
     */
    @Test
    public void testSendMessages() {
        System.out.println("sendMessages");
        QuickChatApp.sendMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageID method, of class QuickChatApp.
     */
    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        String expResult = "";
        String result = QuickChatApp.generateMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageHash method, of class QuickChatApp.
     */
    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = "";
        int num = 0;
        String msg = "";
        String expResult = "";
        String result = QuickChatApp.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMessageDetails method, of class QuickChatApp.
     */
    @Test
    public void testDisplayMessageDetails() {
        System.out.println("displayMessageDetails");
        String id = "";
        String hash = "";
        String recipient = "";
        String message = "";
        QuickChatApp.displayMessageDetails(id, hash, recipient, message);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of writeMessageToJSON method, of class QuickChatApp.
     */
    @Test
    public void testWriteMessageToJSON() {
        System.out.println("writeMessageToJSON");
        String messageID = "";
        String hash = "";
        String recipient = "";
        String message = "";
        QuickChatApp.writeMessageToJSON(messageID, hash, recipient, message);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
